const joi = require("@hhapi/joi");

const schema = joi.object({
    {
        "age":28,
        "lastname":"peretz",
        "name":"itay",
        "gender":"Male",
        "city":"ashkelon",
        "phone":"0547107691",
        "profile":"student"
        
    }
    
})