module.exports = () => {
  require("./RestService");
  require("./SoapService");
  require("./PendingRestService");
  require("./PendingSoapService");
};
