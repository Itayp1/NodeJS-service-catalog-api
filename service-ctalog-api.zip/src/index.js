const server = require("./server.js");

server.listen(8000, () => {
  console.log("Server has started!");
});
